// Student Side.

#include "mbed.h"

#include "SDFileSystem.h"
#include "wave_player.h"
#include "game_synchronizer.h"
#include "tank.h"
#include "bullet.h"
#include "globals.h"
#include "playSound.h"

DigitalOut led1(LED1);
DigitalOut led2(LED2);
DigitalOut led3(LED3);
DigitalOut led4(LED4);
PwmOut led_red(p25); 
PwmOut led_blue(p26); 

DigitalIn pb_u(p21);                        // Up Button
DigitalIn pb_r(p22);                        // Right Button
DigitalIn pb_d(p23);                        // Down Button
DigitalIn pb_l(p24);                        // Left Button

Serial pc(USBTX, USBRX);                    // Serial connection to PC. Useful for debugging!
MMA8452 acc(p28, p27, 100000);              // Accelerometer (SDA, SCL, Baudrate)
uLCD_4DGL uLCD(p9,p10,p11);                 // LCD (tx, rx, reset)
SDFileSystem sd(p5, p6, p7, p8, "sd");      // SD  (mosi, miso, sck, cs)
AnalogOut DACout(p18);                      // speaker
wave_player player(&DACout);                // wav player
Game_Synchronizer sync(PLAYER1);            // Game_Synchronizer (PLAYER)
Timer frame_timer;                          // Timer

// Global variables go here.

int winner = -1;
int whose_turn = PLAYER1;
int counter1 = 0; 
int counter2 = 0; 
int land; 


// Ask the user whether to run the game in Single- or Multi-Player mode.
// Note that this function uses uLCD instead of sync because it is only
// writing to the local (Player1) lcd. Sync hasn't been initialized yet,
// so you can't use it anyway. For the same reason, you must access
// the buttons directly e.g. if( !pb_r ) { do something; }.

// return MULTI_PLAYER if the user selects multi-player.
// return SINGLE_PLAYER if the user selects single-player.
int game_menu(void) {

    uLCD.baudrate(BAUD_3000000);

    // the locate command tells the screen where to place the text.
    uLCD.locate(0,0);
    uLCD.puts("1P&Land1: PB1");
    uLCD.locate(0 ,1);
    uLCD.puts("1P&Land2: PB2");
    uLCD.locate(0,2);
    uLCD.puts("2P&Land1: PB3"); 
    uLCD.locate(0, 3); 
    uLCD.puts("2P&Land2: PB4"); 
    uLCD.locate(0, 10); 
    uLCD.puts("Game History:"); 
    uLCD.locate(0, 11); 
    uLCD.printf("P1 Wins: %d", counter1); 
    uLCD.locate(0, 12); 
    uLCD.printf("P2 Wins: %d", counter2); 
    playSound("/sd/wavfiles/AirHorn.wav"); 
    while (pb_u || pb_d || pb_l || pb_r) {
        if (!pb_u) {
            land = 1; 
            return  SINGLE_PLAYER;
        } else if (!pb_r) {
            land = 2; 
            return  SINGLE_PLAYER;
        } else if (!pb_d) {
            land = 1; 
            return MULTI_PLAYER; 
        } else if (!pb_l) {
            land = 2; 
            return MULTI_PLAYER; 
        }

    }
    // Button Example:
    // Use !pb_r to access the player1 right button value.


    // Eventually you should return SINGLE_PLAYER or MULTI_PLAYER
    // depending on the user's choice.
    return SINGLE_PLAYER;
}

// Initialize the world map. I've provided a basic map here,
// but as part of the assignment you must create more
// interesting map(s).
// Note that calls to sync.function() will run function()
// on both players' LCDs (assuming you are in multiplayer mode).
// In single player mode, only your lcd will be modified. (Makes sense, right?)
void map_init() {
    //landscape 1
    if (land == 1) {
        // Fill the entire screen with sky blue.
        sync.background_color(SKY_COLOR);

        // Call the clear screen function to force the LCD to redraw the screen
        // with the new background color.
        sync.cls();

        // Draw the ground in green.
        sync.filled_rectangle(0,0,128,20, 0x008B45);

        // Draw some obstacles. They don't have to be black,
        // but they shouldn't be the same color as the sky or your tanks.
        // Get creative here. You could use brown and grey to draw a mountain
        // or something cool like that.
        sync.filled_rectangle(59, 20, 69, 90, 0x9B30FF);
    } else { //landsacape 2
        sync.background_color(SKY_COLOR);
        sync.cls();  
        sync.filled_rectangle(0,0,128,20, 0x008B45); 
        sync.filled_rectangle(59, 20, 69, 45, 0x9B30FF);
        //sync.filled_rectangle(40, 46, 75, 70, 0x9B30FF);
    }
    // Before you write text on the screens, tell the LCD where to put it.
    //Common features between both landscapes 
    sync.filled_rectangle(95, 0, 128, 48, 0x008B45); 
    sync.filled_circle(30, 117, 2, 0xFF1493); 
    sync.filled_circle(20, 117, 2, 0xFF1493); 
    sync.filled_circle(98, 117, 2, 0xFF1493); 
    sync.filled_circle(108, 117, 2, 0xFF1493); 
    sync.locate(0,15);

    // Set the text background color to match the sky. Just for looks.
    sync.textbackground_color(SKY_COLOR);

    // Display the game title.
    char title[] = "   Battle Tanks";
    sync.puts(title, sizeof(title));

    // Flush the draw buffer and execute all the accumulated draw commands.
    sync.update();
}

// Initialize the game hardware.
// Call game_menu to find out which mode to play the game in (Single- or Multi-Player)
// Initialize the game synchronizer.
void game_init(void) {

    led1 = 0; led2 = 0; led3 = 0; led4 = 0;
    whose_turn = PLAYER1; 
    pb_u.mode(PullUp);
    pb_r.mode(PullUp);
    pb_d.mode(PullUp);
    pb_l.mode(PullUp);

    pc.printf("\033[2J\033[0;0H");              // Clear the terminal screen.
    pc.printf("I'm alive! Player 1\n");         // Let us know you made it this far.
    int mode = game_menu();
    sync.init(&uLCD, &acc, &pb_u, &pb_r, &pb_d, &pb_l, mode); // Connect to the other player.
    map_init();
    pc.printf("Initialized...\n");              // Let us know you finished initializing.
}

// Display some kind of game over screen which lets us know who won.
// Play a cool sound!
void game_over() {
    //sync.background_color(0x000000); 
    if (winner == 0) {
        counter1++; 
        uLCD.locate(2,10);
        uLCD.puts("Player One Wins");            
    } else {
        counter2++; 
        uLCD.locate(2, 10);
        uLCD.puts("Player Two Wins");
    }
    playSound("/sd/wavfiles/TrainWhistle.wav"); 

}
//method for RGB LED light 
void RGB_light(int r, int b){     
led_red.write(r);       
led_blue.write(b);    
}

int run_game(void) {

    int* p1_buttons;
    int* p2_buttons;
    //life counters
    int  counterP1 = 2; 
    int  counterP2 = 2; 
    //win counters 
    int  counter = 0; 
    int  counter1 = 0; 
    int  other = 0; 
    float ax1, ay1, az1;
    float ax2, ay2, az2;

    game_init();

    // Create your tanks.
    Tank t1(4, 21, 12, 8, TANK_RED);            // (min_x, min_y, width, height, color)
    Tank t2(111, 49, 12, 8, TANK_BLUE);         // (min_x, min_y, width, height, color)

    // For each tank, create a bullet.
    Bullet b1(&t1);
    Bullet b2(&t2); 

    frame_timer.start();

    // Your code starts here...
    while(true) {

        // Get a pointer to the buttons for both sides.
        // From now on, you can access the buttons for player x using
        //
        // px_buttons[U_BUTTON]
        // px_buttons[R_BUTTON]
        // px_buttons[D_BUTTON]
        // px_buttons[L_BUTTON]

        p1_buttons = sync.get_p1_buttons();
        p2_buttons = sync.get_p2_buttons();

        led1 = p1_buttons[0] ^ p2_buttons[0];
        led2 = p1_buttons[1] ^ p2_buttons[1];
        led3 = p1_buttons[2] ^ p2_buttons[2];
        led4 = p1_buttons[3] ^ p2_buttons[3];

        // Get the accelerometer values.
        sync.get_p1_accel_data(&ax1, &ay1, &az1);
        sync.get_p2_accel_data(&ax2, &ay2, &az2);

        if(whose_turn == PLAYER1) {
            //turn indicators 
            sync.triangle(4,126,4,120,12,123, 0xB0171F);
            sync.triangle(123,126,123,119,116,123, 0x4A708B);
            if(ax1 >  ACC_THRESHOLD) {
                // Move the tank to the right if the accelerometer is tipped far enough to the right.
                 t1.reposition(+1, 0, 0);
            } else if (ax1 < (-1 * ACC_THRESHOLD)) {
                t1.reposition(-1,0,0);
            }
            //Move barel
            if (ay1 > ACC_THRESHOLD) {
                t1.reposition(0, 0, PI/100);
            } else if (ay1 < (-1 * ACC_THRESHOLD)) {
                t1.reposition(0,0,-PI/100);
            }
            // Button example - shooting a bullet 
            if (p1_buttons[D_BUTTON]) {
                RGB_light(1,0); 
                playSound("/sd/wavfiles/laser.wav"); 
                b1.shoot();       
            } 
            //decreases the size of the tank 
            if (p1_buttons[R_BUTTON] && counter != 0) {
                t1.erase(); 
                t1.setWidthHeight(6, 4); 
                t1.draw(); 
                sync.update(); 
            }
            //increases the size of the oppenent tank 
            if (p1_buttons[U_BUTTON] && counter != 0) {
                t2.erase(); 
                t2.setWidthHeight(16, 12); 
                t2.draw();
                sync.update();     
            }
            //decreases the speed of the opponents bullet
            if (p1_buttons[L_BUTTON] && counter1 != 0) {
                b2.setSpeed(10); 
            }    
            float dt = frame_timer.read();
            int intersection_code = b1.time_step(dt);
            
            if (intersection_code != BULLET_NO_COLLISION || intersection_code == BULLET_OFF_SCREEN || sync.pixel_eq(intersection_code, 0xFF1493)) {
                pc.printf("Now it's P2's turn!\n");
                whose_turn = PLAYER2;      
            } 
            // If you shot yourself, then your life decreases 
            if(sync.pixel_eq(intersection_code, t1.tank_color)) {
                playSound("/sd/wavfiles/DoorBuzzer.wav"); 
                sync.update();  // Is this necessary?
                counterP1--; 
                if (counterP1 == 0) {
                    sync.filled_circle(30, 117, 2, SKY_COLOR); 
                    winner = PLAYER2; 
                    sync.filled_rectangle(0,0,127,127,0x000000); 
                    sync.update(); 
                    break;    
                } else {
                    sync.filled_circle(20, 117, 2, SKY_COLOR);
                    t1.draw(); 
                }

            }

            // If you shot the other guy, then they lose a life
            //If you shot them twice, then you win
            if(sync.pixel_eq(intersection_code, t2.tank_color)) {
                playSound("/sd/wavfiles/DoorBuzzer.wav");
                sync.update();
                counterP2--; 
                if (counterP2 == 0) {
                    sync.filled_circle(108, 117, 2, SKY_COLOR); 
                    winner = PLAYER1; 
                    sync.filled_rectangle(0,0,127,127,0x000000); 
                    sync.update(); 
                    break;    
                } else {
                    sync.filled_circle(98, 117, 2, SKY_COLOR);  
                    t2.draw(); 
                }
            }
            counter1++; 

        } else if(whose_turn == PLAYER2 && sync.play_mode == SINGLE_PLAYER) {
            // I gave you a lot of the logic for Player1. It's up to you to figure out Player2!
            // If you are in SINGLE_PLAYER mode, you should use the p1 inputs to control p2.
            // In MULTI_PLAYER mode, you should use the p2 inputs to control p2.
            //
            // Hint:
            //         sync.play_mode will tell you if you are in MULTI_PLAYER or SINGLE_PLAYER mode.
            //
                        // Accelerometer example
            //Turn indicators 
            sync.triangle(4,126,4,120,12,123, 0x4A708B);
            sync.triangle(123,126,123,119,116,123, 0xB0171F);
            //Since tank 2 is on a hill, the tank will adjust itself if it goes beyond the hill 
            if(ax1 >  ACC_THRESHOLD) {
                // Move the tank to the right if the accelerometer is tipped far enough to the right.
                 t2.reposition(+1, 0, 0);
            } else if (ax1 < (-1 * ACC_THRESHOLD)) {
                t2.reposition(-1,0,0);
                if (sync.pixel_eq(sync.read_pixel(t2.min_x(), t2.min_y() - 1),SKY_COLOR) && other == 0) {
                    other++; 
                    t2.erase(); 
                    t2.setSX(78); 
                    t2.setSY(21); 
                    t2.draw(); 
                    sync.update();    
                }
            }
            //Move barel
            if (ay1 > ACC_THRESHOLD) {
                t2.reposition(0, 0, PI/100);
            } else if (ay1 < (-1 * ACC_THRESHOLD)) {
                t2.reposition(0,0,-PI/100);
            }
            // Button example
            if (p1_buttons[D_BUTTON]) {
                RGB_light(0,1); 
                playSound("/sd/wavfiles/laser.wav"); 
                b2.shoot();
            }
            //Decreases the size of the tank 
            if (p1_buttons[R_BUTTON] && counter1 != 0) {
                t2.erase(); 
                t2.setWidthHeight(6, 4); 
                t2.draw(); 
                sync.update(); 
            }
            //Increases the size of the oppoenents tank 
            if (p1_buttons[U_BUTTON] && counter1 != 0) {
                t1.erase(); 
                t1.setWidthHeight(16, 12); 
                t1.draw();
                sync.update();     
            }
            //Decreases the speed of the oppenents bullet 
            if (p1_buttons[L_BUTTON] && counter1 != 0) {
                b1.setSpeed(10); 
            }    

            float dt = frame_timer.read();
            int intersection_code = b2.time_step(dt);
            //if you miss, then its the other player's turn 
            if(intersection_code != BULLET_NO_COLLISION || intersection_code == BULLET_OFF_SCREEN || sync.pixel_eq(intersection_code, 0xFF1493)) {
                pc.printf("Now it's P1's turn!\n");
                whose_turn = PLAYER1;
            }

            // If you shot yourself, you lose a life.
            if(sync.pixel_eq(intersection_code, t2.tank_color)) {
                playSound("/sd/wavfiles/DoorBuzzer.wav");
                sync.update();  // Is this necessary?
                counterP2--; 
                if (counterP2 == 0) {
                    sync.filled_circle(108, 117, 2, SKY_COLOR); 
                    winner = PLAYER1; 
                    sync.filled_rectangle(0,0,127,127,0x000000); 
                    sync.update(); 
                    break; 
                } else {
                    sync.filled_circle(98, 117, 2, SKY_COLOR);   
                    t2.draw();  
                }

            }

            // If you shot the other guy twice then you win.
            // Otherwise they lose a life
            if(sync.pixel_eq(intersection_code, t1.tank_color)) {
                playSound("/sd/wavfiles/DoorBuzzer.wav");
                sync.update();
                counterP1--;  
                if (counterP1 == 0) {
                    sync.filled_circle(20, 117, 2, SKY_COLOR); 
                    winner = PLAYER2; 
                    sync.filled_rectangle(0,0,127,127,0x000000); 
                    sync.update(); 
                    break;   
                } else {
                    sync.filled_circle(30, 117, 2, SKY_COLOR); 
                    t1.draw();   
                }
            }
            counter++; 

        } else if(whose_turn == PLAYER2 && sync.play_mode == MULTI_PLAYER) {
            // I gave you a lot of the logic for Player1. It's up to you to figure out Player2!
            // If you are in SINGLE_PLAYER mode, you should use the p1 inputs to control p2.
            // In MULTI_PLAYER mode, you should use the p2 inputs to control p2.
            //
            // Hint:
            //         sync.play_mode will tell you if you are in MULTI_PLAYER or SINGLE_PLAYER mode.
            //
                        // Accelerometer example
            //turn indicators 
            sync.triangle(4,126,4,120,12,123, 0x4A708B);
            sync.triangle(123,126,123,119,116,123, 0xB0171F);
            if(ax2 >  ACC_THRESHOLD) {
                // Move the tank to the right if the accelerometer is tipped far enough to the right.
                // Since tank 2 is on a hill, it will adjust itself if it goes beyond the hill 
                 t2.reposition(+1, 0, 0);
            } else if (ax2 < (-1 * ACC_THRESHOLD)) {
                 t2.reposition(-1,0,0);
                 if (sync.pixel_eq(sync.read_pixel(t2.min_x(), t2.min_y() - 1),SKY_COLOR) && other == 0) {
                    other++; 
                    t2.erase(); 
                    t2.setSX(78); 
                    t2.setSY(21); 
                    t2.draw(); 
                    sync.update(); 
                }
            }
            //Move barrel
            if (ay2 > ACC_THRESHOLD) {
                t2.reposition(0, 0, PI/100);
            } else if (ay2 < (-1 * ACC_THRESHOLD)) {
                t2.reposition(0,0,-PI/100);
            }
            // Button example 
            if (p2_buttons[D_BUTTON]) {
                RGB_light(0,1);
                playSound("/sd/wavfiles/laser.wav");  
                b2.shoot();
            }
            //Decreases the size of the tank 
            if (p1_buttons[R_BUTTON] && counter1 != 0) {
                t2.erase(); 
                t2.setWidthHeight(6, 4); 
                t2.draw(); 
                sync.update(); 
            }
            //Increases the size of the oppoenent's tank 
            if (p1_buttons[U_BUTTON] && counter1 != 0) {
                t1.erase(); 
                t1.setWidthHeight(16, 12); 
                t1.draw();
                sync.update();     
            }      
            //Decreases the speed of the oppenent's bullet 
            if (p1_buttons[L_BUTTON] && counter1 != 0) {
                b1.setSpeed(10); 
            }    

            float dt = frame_timer.read();
            int intersection_code = b2.time_step(dt);
            
            if(intersection_code != BULLET_NO_COLLISION || intersection_code == BULLET_OFF_SCREEN || sync.pixel_eq(intersection_code, 0xFF1493)) {
                pc.printf("Now it's P1's turn!\n");
                whose_turn = PLAYER1;
            }

            // If you shot yourself, you lost.
            if(sync.pixel_eq(intersection_code, t2.tank_color)) {
                playSound("/sd/wavfiles/DoorBuzzer.wav");
                sync.update();  // Is this necessary?
                counterP2--; 
                if (counterP2 == 0) {
                    sync.filled_circle(108, 117, 2, SKY_COLOR); 
                    winner = PLAYER1; 
                    sync.filled_rectangle(0,0,127,127,0x000000); 
                    sync.update(); 
                    break; 
                } else {
                    sync.filled_circle(98, 117, 2, SKY_COLOR);   
                    t2.draw();  
                }

            }
            counter++; 
            // If you shot the other guy, you won!
            if(sync.pixel_eq(intersection_code, t1.tank_color)) {
                playSound("/sd/wavfiles/DoorBuzzer.wav");
                sync.update();
                counterP1--;  
                if (counterP1 == 0) {
                    sync.filled_circle(20, 117, 2, SKY_COLOR); 
                    winner = PLAYER2; 
                    sync.filled_rectangle(0,0,127,127,0x000000); 
                    sync.update(); 
                    break;   
                } else {
                    sync.filled_circle(30, 117, 2, SKY_COLOR); 
                    t1.draw();   
                }
            }
        }
        frame_timer.reset();
        sync.update();
    }
    //Call game over 
    //Resets the number of lives
    //And restarts the game (in order to keep the game history)
    game_over(); 
    counterP1 = 2; 
    counterP2 = 2; 
    while (true) {
        if (!pb_d) {
            sync.filled_rectangle(0,0,128,128, 0x00000); 
            sync.update(); 
            run_game(); 
            return winner;     
        }    
    }

}
int main(void) {
    run_game();    
}